#include "player.h"

void addAtEnd(Node **head, char team_name[50], int team_size, FILE* file) // functie care adauga noduri (echipe)
{

	//creare nod
    Node *aux = *head;
    Node *newNode = (Node *)malloc(sizeof(Node));

	//adaugare dimensiune echipa
	newNode->team_size = team_size;
	newNode->players_in_team = (Player* )malloc(sizeof(Player) * team_size);	

	//stergerea spatiilor din fisier
    int start = 0;
    while (isspace((unsigned char)team_name[start]))
    {
        start++;
    }
    
    int end = strlen(team_name) - 1;
    while (end >= 0 && isspace((unsigned char)team_name[end]))
    {
        end--;
    }
    
    int trimmed_length = end - start + 1;
    
    // Adaugare nume echipa
    newNode->team_name = (char*)malloc(trimmed_length + 1);
    strncpy(newNode->team_name, &team_name[start], trimmed_length);
    newNode->team_name[trimmed_length] = '\0';

	//inserare pe rand a jucatorilor in echipa
    for (int k = 0; k < team_size; k++) 
    {
		//salvarea numelui jucatorului
		char buffer[50];
		fscanf(file, "%s", buffer);
		newNode->players_in_team[k].firstName = (char *)malloc( strlen(buffer) + 1);
        strcpy(newNode->players_in_team[k].firstName, buffer);

		//salvarea prenumelui jucatorului
		fscanf(file, "%s", buffer);
		newNode->players_in_team[k].secondName = (char *)malloc( strlen(buffer) + 1);
        strcpy(newNode->players_in_team[k].secondName, buffer);

		//salvarea punctelor jucatorului
		fscanf(file, "%f", &newNode->players_in_team[k].points);
    }
	newNode->next = *head;
    *head = newNode;
}

void Display (Node* head, FILE* g)
{
	//afisarea nodurilor mai putin pe ultimul
	while (head->next != NULL)
	{
		fprintf(g, "%s\n", head->team_name);
		head = head->next;
	}

	//afisarea ultimului nod
	if (head->next == NULL)
		fprintf(g, "%s", head->team_name);
		
}	

float teamAverage (Node* team) //functie care calculeaza media unei echipe
{
		float suma = 0;
		float media;
		for ( int i = 0; i < team->team_size; i++)
			suma += team->players_in_team[i].points;
		media = suma / team->team_size;
		return media;
}

float minimum (Node* head) //functie care calculeaza minimul de punctaj din lista
{
	float min = INFINITY;
	float epsilon = 0.000001;
	while (head->next != NULL)
	{
		float medie = teamAverage(head);
		if (  teamAverage(head) < min)
			min = medie;
	head = head->next;
	}
	return min;
}

void removeNodes(Node** head)
{
	Node* aux = *head;
	
	//scorul minim dintre echipele ramase
	float min = minimum(aux);

	float epsilon = 0.000001;
	Node* precedent = NULL; //nodul precedent caruia ii trebuie modificata legatura in caz de stergerea nodului precedent->next

	while (aux != NULL)
	{
		
		float avg = teamAverage(aux);
		if (fabs(avg - min) < epsilon)
		{
			//verificare daca primul nod trebuie scos
			if (precedent == NULL)
				*head = aux->next;
			else
				precedent->next = aux->next;
			
			//eliberarea memoriei ocupata de nod si toate componentele lui
			for (int i = 0; i < aux->team_size; i++) 
			{
				free(aux->players_in_team[i].firstName);
				free(aux->players_in_team[i].secondName);
			}
			free(aux->players_in_team);
			free(aux->team_name);
			Node* temp = aux;
			aux = aux->next;
			free(temp);
			return;
		}
		precedent = aux;
		aux = aux->next;
	}
}

//creare coada
matchQueue* createQueue()
{
	matchQueue* q;
	q = (matchQueue *) malloc(sizeof ( matchQueue));
	q->front = q->rear = NULL;
	return q;
}

//populare coada
void enterQueue ( matchQueue* q, Node* team)
{
	//adaugarea datelor in nodul nou din coada
	Node* newNode = (Node *) malloc( sizeof( Node));
	newNode->team_name = (char* ) malloc( strlen(team->team_name) + 1);
	strcpy( newNode->team_name, team->team_name);
	newNode->team_size = team->team_size;
	newNode->players_in_team = (Player *) malloc( sizeof( Player) * newNode->team_size);
	for ( int k = 0; k < team->team_size; k++)
	{
		newNode->players_in_team[k].firstName = (char *) malloc( strlen(team->players_in_team[k].firstName) + 1);
		strcpy( newNode->players_in_team[k].firstName, team->players_in_team[k].firstName);

		newNode->players_in_team[k].secondName = (char *) malloc( strlen(team->players_in_team[k].secondName) + 1);
		strcpy( newNode->players_in_team[k].secondName, team->players_in_team[k].secondName);

		newNode->players_in_team[k].points = team->players_in_team[k].points;
	}
	newNode->next = NULL;
	if( q->rear == NULL)
		q->rear = newNode;

	else 
	{
		(q->rear)->next = newNode;
		(q->rear) = newNode;

	}	
	if ( q->front == NULL) 
		q->front = q->rear;
}

int isEmpty ( matchQueue* q)
{
	return(q->front == NULL ? 1 : 0);
}
	
//functie care copiaza 2 noduri
void copyNodeData ( Node* nod_destinatie, Node* nod_sursa)
{
	nod_destinatie->team_size = nod_sursa->team_size;
	nod_destinatie->players_in_team = (Player* ) malloc( sizeof(Player) * (nod_destinatie->team_size));
	nod_destinatie->team_name = (char* ) malloc (strlen(nod_sursa->team_name) + 1);
	strcpy( nod_destinatie->team_name, nod_sursa->team_name);
	for ( int k = 0; k < nod_destinatie->team_size; k++)
	{
		nod_destinatie->players_in_team[k].firstName = (char *) malloc( strlen(nod_sursa->players_in_team[k].firstName) + 1);
		strcpy( nod_destinatie->players_in_team[k].firstName, nod_sursa->players_in_team[k].firstName);

		nod_destinatie->players_in_team[k].secondName = (char *) malloc( strlen(nod_sursa->players_in_team[k].secondName) + 1);
		strcpy(nod_destinatie->players_in_team[k].secondName, nod_sursa->players_in_team[k].secondName);

		nod_destinatie->players_in_team[k].points = nod_sursa->players_in_team[k].points;
	}
}
//scoate din queue 
Node* deQueue (matchQueue* q)
{
	if( isEmpty( q)) return NULL;
	Node* aux_de_sters;
	Node* aux_de_returnat = (Node*)malloc(sizeof(Node));
	
	aux_de_sters = q->front;
	copyNodeData( aux_de_returnat, aux_de_sters);
	printf("nod copiat in aux_de_returnat: %s\n", aux_de_returnat->team_name);
	q->front = (q->front)->next;
	freeNodeData(aux_de_sters);
	free(aux_de_sters);
	return aux_de_returnat;

}


void addPoints (Node* winners)
{
	float rata_de_adaugare = 1 / winners->team_size;
	for ( int k = 0; k < winners->team_size; k++)
		winners->players_in_team[k].points += rata_de_adaugare;
}


//functie care aranjeaza meciuri 
void matchMaker (matchQueue* q, Node** winnerStack, Node** loserStack)
{
	Node* first_team = deQueue(q);
	Node* second_team = deQueue(q);
	printf("Prima echipa din coada si scorul jucatorilor:%s %2.3f\n",first_team->team_name, teamAverage(first_team));
	printf("A doua echipa din coada si scorul jucatorilor:%s %2.3f\n",second_team->team_name, teamAverage(second_team));
	float epsilon = 0.00001;
	printf("epsilon : %2.3f", epsilon);
	float first_avg = teamAverage(first_team);
	float second_avg = teamAverage(second_team);
	if ( teamAverage(first_team) > teamAverage(second_team) || fabs(  teamAverage(first_team) - teamAverage(second_team)) < epsilon )
	{
		printf("Meciul e intre : %s %s\n", first_team->team_name, second_team->team_name);
		addPoints(first_team);
		push(&*winnerStack, first_team);
		push(&*loserStack, second_team);
		
	}
	else if ( teamAverage(first_team) < teamAverage(second_team))
	{
		
		addPoints(second_team);
		push(&*winnerStack, second_team);
		push(&*loserStack, first_team);
		
	}
		
}

void push (Node** top, Node* team)
{
	Node* newNode = (Node*)malloc (sizeof(Node));
	copyNodeData( newNode, team);
	newNode->next = *top;
	*top = newNode;
}

int isEmptyStack (Node* top)	
	{
		return top == NULL ? 1:0;
	}

Node* pop (Node** top)
{
	if (isEmptyStack(*top)) return NULL;
	Node* temp = (*top);
	Node* aux = (Node* ) malloc(sizeof(Node));
	copyNodeData(aux, *top);
	*top = (*top)->next;
	freeNodeData(temp);
	free(temp);
	return aux;
}

void freeNodeData (Node* nod_de_eliberat)
{
	for ( int k = 0; k < nod_de_eliberat->team_size; k++)
	{
		free(nod_de_eliberat->players_in_team[k].firstName);
		free(nod_de_eliberat->players_in_team[k].secondName);
	}
	free(nod_de_eliberat->team_name);
}