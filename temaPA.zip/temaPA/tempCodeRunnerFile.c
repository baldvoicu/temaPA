char buffer[30];
		fscanf(f, "%s", buffer);
		printf("buffer: %s\n", buffer);
		newNode->players_in_team[k].firstName = (char *)malloc( strlen(buffer) + 1);
        strcpy(newNode->players_in_team[k].firstName, buffer);
		printf("%s\t", newNode->players_in_team[k].firstName);