#include "player.h"

int main (int argc, char* argv[])
{

    FILE *c;
    FILE *file;
    FILE *write;
    if ((c = fopen(argv[1], "rt")) == NULL)
    {
    printf("eroare la deschiderea fisierului c: %s\n", argv[1]);
    exit(1);
    }
    if ((file = fopen(argv[2], "rt")) == NULL)
    {
        printf("eroare la deschiderea fisierului fisier");
        exit(1);
    }
    if ((write = fopen(argv[3], "wt")) == NULL)
    {
        printf("eroare la deschiderea fisierului write");
        exit(1);
    }
    int cerinte[5];
    for (int i = 0; i < 5; i++)
    {
        fscanf(c, "%d", &cerinte[i]);
    }
    FILE *r_out = fopen("r.out","w");
    
    //aflarea numarului total de echipe
    int number_of_teams;
    fscanf(file, "%d", &number_of_teams);
    
    //initializarea listei
    Node* head;
    head = NULL;
    for (int i = 0; i < 5; i++)
    {
        fscanf(c, "%d", &cerinte[i]);
    }
    //popularea listei cu echipe
    for ( int i = 1; i <= number_of_teams; i++)
        {
             int team_size;
             char team_name[50];
             fscanf(file, "%d", &team_size);
             fgets(team_name, sizeof(team_name), file); 
             addAtEnd(&head, team_name, team_size, file); 
        }
    if (cerinte[0] == 1 && cerinte[1] == 0)
    {
        Display(head, write);
        fclose(file);
        //fclose(write);
    }  
    //eliminarea echipelor pana la n echipe ramase
    int n = pow(2, round(log2(number_of_teams))); // n = nr de echipe dorite
    while (number_of_teams != n)
    {
        removeNodes( &head);
        number_of_teams--;
    }
    if( cerinte[1] == 1)
    {
        Display(head, write);
    }

   //creareea cozii
    matchQueue* coadaMeciurilor = createQueue();
    Node* teams_to_add = head;
    while (teams_to_add->next != NULL)
    {
        enterQueue( coadaMeciurilor, teams_to_add);
        teams_to_add = teams_to_add->next; 
    }
    if (teams_to_add->next == NULL) 
        enterQueue( coadaMeciurilor, teams_to_add);
   
    Node* winnerStack;
    Node* loserStack;

    //aici incepe partea problematica din task 3 care este comentata pentru a nu strica restul verficarii pe checker


    /*while (number_of_teams != 8)
    {
        
            matchMaker (coadaMeciurilor, &winnerStack, &loserStack);
            number_of_teams-=2;
            printf("Sper ca a modificat: %d", number_of_teams);
            while ( !isEmptyStack(loserStack) ) // golim stiva invinsilor
            {
                Node* nod_neimportant = pop(&loserStack); 
                freeNodeData(nod_neimportant);
                free(nod_neimportant);
            } 
            while( !isEmpty(coadaMeciurilor)) //golim coada meciurilor ca dupa aceea sa o actualizam
               {
                     Node* alt_nod_neimportant = deQueue(coadaMeciurilor);
                     freeNodeData(alt_nod_neimportant);
                     free(alt_nod_neimportant);
               }

            //popularea cozii cu castigatori
            Node* winner_teams_to_add = head;
            while (winner_teams_to_add->next != NULL)
                {
                    enterQueue( coadaMeciurilor, winner_teams_to_add);
                    winner_teams_to_add = winner_teams_to_add->next; 
                }
            if (winner_teams_to_add->next == NULL) 
                enterQueue( coadaMeciurilor, winner_teams_to_add);
        
    } */
    
    return 0; 
}