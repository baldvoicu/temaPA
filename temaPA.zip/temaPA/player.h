#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
#include<ctype.h>
//structura unui singur jucator
struct Player
{
    char *firstName;
    char *secondName;
    float points;
};
typedef struct Player Player;

//structura unei echipe
struct Node
{
    int team_size;
    char* team_name;
    Player *players_in_team;
    struct Node* next;

};
typedef struct Node Node;

struct matchQueue
{
    Node* front;
    Node* rear;
};
typedef struct matchQueue matchQueue;


typedef struct winnerStack winnerStack;

//functii folosite in principiu la task 1
void addAtEnd(Node **head,char* team_name, int team_size, FILE* f);
void Display (Node* head, FILE* g);

//functii folosite in principiu la task2
float teamAverage (Node* team);
float minimum (Node* head);
void removeNodes(Node** head);

//functii folosite in principiu la task 3 
matchQueue* createQueue(); // creeaza coada
void enterQueue ( matchQueue* q, Node* team); //adauga noduri in coada
int isEmpty ( matchQueue* q); // verifica daca e goala coada
Node* deQueue (matchQueue* q); //scoate din coada un nod
void copyNodeData ( Node* nod_destinatie, Node* nod_sursa); // copiaza datele unui nod
void matchMaker (matchQueue* q, Node** winnerStack, Node** loserStack); //organizaeaza meciurile
void push (Node** top, Node* team); // baga in stiva
Node* pop (Node** top); // scoate din stiva
int isEmptyStack (Node* top); // verifica daca e goala stiva
void freeNodeData (Node* nod_de_eliberat); // elibereaza contimnutul unui nod