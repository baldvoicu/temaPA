 1.		Pentru primul task am citit numarul de echipe pentru a determina nr de pasi necesari pentru a insera fiecare nod
	(echipa) in lista. Stiind ca puteam insera noduri in lista pana la finalul fisierul "d.in" am optat pentru aceasta metoda
	pentru a pastra in  main numarul de echipe, variabila ce va fi utila in urmatoarele taskuri.
		In inserarea nodurilor am adaugat o secventa de cod pentru a sterge whitespace-urile pentru a evita comparatiile eronate 
	cu fisierul de rezultate.
2. 		Pentru al doilea task am facut un set de pasi generali care m au ajutat in rezolvarea eliminarii nodurilor:
		"-in main calculam cate n echipe trb sa ramana 
		 -in main apelam functia de eliminare a echipelor pana cand number_of_teams == n
			-in functie apelam alta functie care determina noul minim
			-in functie parcurgem fiecare echipa din list si comparam cu minim media echipei
				-daca media echipei e mai mica , scoatem echipa din lista si iesim din functie
				-altfel trecem la urmatoarea echipa "
		Dupa aceea am creat functii precum teamAverage si minimum pentru a facilita calculule, cat si pentru a face mai lizibil codul
3.		Pentru taskul 3, desi a ramas incomplet datorita unui segmentation fault, am scris din nou un "indrumar propriu":
		"structurile care trebuie create:
			-o coada cu meciuri numita matchQueue
			-o stiva pt castigatori nuumita winnerStack
			-o stiva pt invinsi numita loserStack
			-o lista cu cei 8 castigatori
		 -functiile care trebuie create: 
			-o functie care aranjeaza meciurile
			-o functie care repartizeaza castigatorii (incrementand punctajul) si pierzatorii
			-o functie care elibereaza loserStack". 
		While-ul spre finalul main-ului are scopul de a rula meciurile pana la ultimele 8 echipe. segmentation fault-ul apare in 
		functia "matchMaker" fix inaintea if-ului.

	
		